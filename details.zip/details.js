document.getElementById('detail').textContent = 'subpackage ready';
document.getElementById('back').addEventListener('click', () => Hybrid.call('page.back').catch(() => {}));
