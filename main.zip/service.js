'use strict';
let counter = 0;
Hybrid.on('page.ready', () => Hybrid.publish('counter.changed', counter));
Hybrid.on('counter.increment', async () => {
  counter += 1;
  await Hybrid.publish('counter.changed', counter);
});
Hybrid.on('app.reopen', () => Hybrid.publish('counter.changed', counter));
