'use strict';
const nativeLoginButton = document.getElementById('native-login');
const nativeLoginResult = document.getElementById('native-login-result');
nativeLoginButton.addEventListener('click', async () => {
  if (nativeLoginButton.disabled) return;
  nativeLoginButton.disabled = true;
  nativeLoginResult.textContent = '请在原生页面完成登录…';
  try {
    const result = await Hybrid.call('host.presentLogin', {});
    nativeLoginResult.textContent = result.status === 'authenticated'
      ? `模拟登录成功，用户名：${result.username}` : '已取消登录，可再次打开。';
  } catch (error) {
    const messages = {busy:'原生页面正在使用，请稍后重试。',timeout:'登录已超时，请重新打开。',cancelled:'登录已中断，请重试。',background:'应用已进入后台，请重新登录。',api_denied:'当前资源未开放原生登录接口。'};
    nativeLoginResult.textContent = messages[error.code] || '暂时无法打开原生登录，请在 HybridKit 容器内重试。';
  } finally { nativeLoginButton.disabled = false; }
});
const output = document.getElementById('result');
function show(value) { output.textContent = JSON.stringify(value, null, 2); }
function action(id, handler) {
  document.getElementById(id).addEventListener('click', async () => {
    try { show(await handler()); } catch (error) { show({code:error.code,message:error.message}); }
  });
}
Hybrid.on('counter.changed', value => { document.getElementById('counter').textContent = value; document.getElementById('status').textContent = 'ready'; });
action('increment', () => Hybrid.publish('counter.increment'));
action('echo', () => Hybrid.call('host.echo', {message:'Hello from WKWebView'}));
action('save', () => Hybrid.call('storage.set', {key:'demo.note',value:{text:'我的本地数据',savedAt:new Date().toISOString()}}));
action('read', () => Hybrid.call('storage.get', {key:'demo.note'}));
action('permission', () => Hybrid.call('permission.request', {scope:'profile'}));
action('info', () => Hybrid.callSync('runtime.info'));
action('navigate', () => Hybrid.call('page.navigate', {page:'details'}));

const credentialsForm = document.getElementById('credentials-form');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const togglePassword = document.getElementById('toggle-password');
const submitCredentials = document.getElementById('submit-credentials');
const credentialsResult = document.getElementById('credentials-result');
let credentialsRevision = 0;

function setPasswordVisible(visible) {
  passwordInput.type = visible ? 'text' : 'password';
  togglePassword.textContent = visible ? '隐藏' : '显示';
  togglePassword.setAttribute('aria-label', visible ? '隐藏密码' : '显示密码');
  togglePassword.setAttribute('aria-pressed', String(visible));
}

usernameInput.addEventListener('input', () => usernameInput.setCustomValidity(''));
togglePassword.addEventListener('click', () => {
  setPasswordVisible(passwordInput.type === 'password');
});

credentialsForm.addEventListener('submit', async event => {
  event.preventDefault();
  if (submitCredentials.disabled) return;
  const username = usernameInput.value.trim();
  usernameInput.setCustomValidity(username ? '' : '请输入用户名');
  if (!credentialsForm.reportValidity()) return;

  const revision = ++credentialsRevision;
  // Only send input metadata through the echo API, never the password itself.
  const parameters = {
    test: 'credentials-input',
    username,
    passwordLength: Array.from(passwordInput.value).length
  };
  passwordInput.value = '';
  setPasswordVisible(false);
  submitCredentials.disabled = true;
  submitCredentials.textContent = '测试中…';
  credentialsResult.textContent = '正在提交输入测试…';
  try {
    const response = await Hybrid.call('host.echo', parameters);
    if (revision !== credentialsRevision) return;
    credentialsResult.textContent = JSON.stringify({
      status: '输入测试完成',
      username: parameters.username,
      passwordLength: parameters.passwordLength,
      hostUser: response.user
    }, null, 2);
  } catch (error) {
    if (revision !== credentialsRevision) return;
    credentialsResult.textContent = JSON.stringify({
      status: '输入测试失败，请重新输入密码后重试',
      code: error.code || 'operation_failed'
    }, null, 2);
  } finally {
    if (revision === credentialsRevision) {
      submitCredentials.disabled = false;
      submitCredentials.textContent = '提交测试';
    }
  }
});

credentialsForm.addEventListener('reset', () => {
  credentialsRevision += 1;
  usernameInput.setCustomValidity('');
  setPasswordVisible(false);
  submitCredentials.disabled = false;
  submitCredentials.textContent = '提交测试';
  credentialsResult.textContent = '等待输入测试数据';
});
